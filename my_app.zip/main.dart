
// TruTribe Flutter App (MVP Boot)
// Simplified placeholder for app entry point
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(home: Scaffold(body: Center(child: Text('TruTribe MVP Boot')))));
}
